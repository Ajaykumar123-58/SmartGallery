# SmartGallery — Android Project (Kotlin + Jetpack Compose)

Package ID: `com.smartgallery.app`.

## इस source में मौजूद
- MediaStore से फोटो/वीडियो सूची दिखाना।
- सामान्य Delete Box के लिए 7 दिन की ऐप-रिकॉर्ड अवधि।
- उपयोगकर्ता द्वारा खुद चुने गए Explicit Box रिकॉर्ड के लिए 24 घंटे की ऐप-रिकॉर्ड अवधि।
- Restore/delete actions में Android system confirmation APIs।
- फोटो के लिए on-device NSFW score integration: हर फोटो के सामने **AI जाँच** बटन।
- AI का परिणाम सिर्फ सुझाव/मैन्युअल समीक्षा के लिए है। AI अपने-आप फोटो delete या Explicit Box में नहीं डालता।
- PIN, password या biometric lock नहीं है।

## AI मॉडल की ज़रूरी बात
इस ZIP में AI library integration है, लेकिन मॉडल फ़ाइल `nsfw.tflite` शामिल नहीं हो सकी। असली मॉडल के बिना AI जाँच नहीं चलेगी।

1. मॉडल के स्रोत/निर्देश: https://github.com/devzwy/open_nsfw_android
2. उस स्रोत से `nsfw.tflite` मॉडल प्राप्त करें (README में download link है)।
3. फ़ाइल को `app/src/main/assets/nsfw.tflite` नाम से रखें। इस ZIP में `assets/README_MODEL_HINDI.txt` भी है।

यह पुराना/archived open-source NSFW model है। यह मुख्यतः नग्न/यौन सामग्री का अनुमान देता है, हर तरह की असुरक्षित सामग्री नहीं। गलत positive/negative परिणाम हो सकते हैं; इसलिए परिणाम के आधार पर अपने-आप deletion नहीं होती। स्रोत: https://github.com/devzwy/open_nsfw_android (archived 2023).

## अभी क्या प्रमाणित नहीं है
- इस वातावरण में Android SDK/Gradle उपलब्ध नहीं होने से project build या device test नहीं किया गया।
- APK इस ZIP में शामिल नहीं है।
- Android 11+ के system trash/delete rules लागू होते हैं। ऐप expiry पर Android confirmation माँगता है; बिना अनुमति दूसरी apps की media को चुपचाप मिटाने की गारंटी नहीं है।

## APK बनाने के चरण
1. ZIP extract करें।
2. Android Studio में `SmartGallery_Corrected_Project` root folder खोलें।
3. JDK 17 और Android SDK Platform 35 install/sync करें।
4. AI test करने के लिए ऊपर बताई `nsfw.tflite` फ़ाइल जोड़ें।
5. **Build > Build Bundle(s) / APK(s) > Build APK(s)** चुनें।
6. Build सफल होने पर Android Studio के `locate` लिंक से APK खोलें; सामान्य path `app/build/outputs/apk/debug/app-debug.apk` है।

## फोन पर test checklist
- [ ] Install और launch
- [ ] Photo/video permission grant/deny
- [ ] AI model मौजूद होने पर फोटो का AI scan; model न होने पर साफ error message
- [ ] AI result से कोई media अपने-आप delete न हो
- [ ] Normal delete/restore और system confirmation
- [ ] Explicit Box केवल user confirmation से
- [ ] Expiry पर confirmation; cancel करने पर deleted न बताया जाए

**स्थिति:** AI scan code और dependency जोड़े गए हैं; model file, successful build और वास्तविक फोन परीक्षण बाकी हैं।
