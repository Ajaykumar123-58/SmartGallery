SMARTGALLERY AI MODEL FILE

AI scan के लिए open_nsfw_android का nsfw.tflite model इस folder में रखें:
app/src/main/assets/nsfw.tflite

यह placeholder file model नहीं है। असली model के बिना AI स्कैन काम नहीं करेगा।
Model source and usage notes:
https://github.com/devzwy/open_nsfw_android
यह पुराना/archived model है; false positive और false negative संभव हैं। परिणाम को
सिर्फ review suggestion मानें। इस ऐप में AI अपने-आप कोई मीडिया delete नहीं करता।
