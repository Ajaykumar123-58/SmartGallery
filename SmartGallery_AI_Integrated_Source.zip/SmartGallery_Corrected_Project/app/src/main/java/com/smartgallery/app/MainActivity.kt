package com.smartgallery.app

import android.Manifest
import android.graphics.BitmapFactory
import android.app.PendingIntent
import android.content.ContentUris
import android.content.Context
import android.content.IntentSender
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.MoreVert
import io.github.devzwy.nsfw.NSFWHelper
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

private const val PREFS = "smart_gallery_store"
private const val KEY_TRASH = "trash_records"
private const val NORMAL = "NORMAL"
private const val EXPLICIT = "EXPLICIT"
private const val DAY_MS = 86_400_000L
private const val WEEK_MS = 7L * DAY_MS

/** On-device NSFW scoring. This only flags for human review; it never deletes media. */
private object SmartGalleryAi {
    private val initialized = AtomicBoolean(false)

    @Synchronized
    fun initialize(context: Context) {
        if (initialized.get()) return
        // The library requires nsfw.tflite in app/src/main/assets/.
        NSFWHelper.initHelper(context.applicationContext, null, false, 2)
        initialized.set(true)
    }
}

data class MediaEntry(val id: Long, val uri: Uri, val name: String, val isVideo: Boolean, val dateAdded: Long)
data class TrashRecord(val key: String, val uri: String, val name: String, val isVideo: Boolean, val deletedAt: Long, val type: String) {
    val expiryAt: Long get() = deletedAt + if (type == EXPLICIT) DAY_MS else WEEK_MS
}

class MainActivity : ComponentActivity() {
    private var refreshAfterAction: (() -> Unit)? = null
    private var pendingRecord: TrashRecord? = null
    private var pendingMedia: MediaEntry? = null
    private var pendingAction: String = ""

    private val systemRequest = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        val approved = result.resultCode == RESULT_OK
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val records = loadTrash(prefs).toMutableList()
        when (pendingAction) {
            "TRASH_NORMAL", "TRASH_EXPLICIT" -> {
                if (approved) {
                    val item = pendingMedia
                    if (item != null) {
                        records.add(TrashRecord(UUID.randomUUID().toString(), item.uri.toString(), item.name, item.isVideo, System.currentTimeMillis(), if (pendingAction == "TRASH_EXPLICIT") EXPLICIT else NORMAL))
                        saveTrash(prefs, records)
                        toast("मीडिया Delete Box में रखी गई।")
                    }
                } else toast("अनुमति नहीं मिली; मीडिया नहीं बदली गई।")
            }
            "RESTORE" -> {
                if (approved && pendingRecord != null) {
                    saveTrash(prefs, records.filterNot { it.key == pendingRecord!!.key })
                    toast("मीडिया restore कर दी गई।")
                } else toast("Restore रद्द हुआ या सफल नहीं हुआ।")
            }
            "PERMANENT_DELETE", "EXPIRED_DELETE" -> {
                if (approved) {
                    val removeKeys = if (pendingAction == "EXPIRED_DELETE") records.filter { it.expiryAt <= System.currentTimeMillis() }.map { it.key }.toSet() else setOfNotNull(pendingRecord?.key)
                    saveTrash(prefs, records.filterNot { it.key in removeKeys })
                    toast("स्थायी deletion की अनुमति स्वीकार हुई।")
                } else toast("स्थायी deletion रद्द हुई; रिकॉर्ड बॉक्स में रखा गया है।")
            }
        }
        pendingAction = ""
        pendingRecord = null
        pendingMedia = null
        refreshAfterAction?.invoke()
    }

    fun launchSystemRequest(sender: IntentSender) {
        systemRequest.launch(IntentSenderRequest.Builder(sender).build())
    }

    fun setPending(action: String, media: MediaEntry? = null, record: TrashRecord? = null) {
        pendingAction = action
        pendingMedia = media
        pendingRecord = record
    }

    fun trashMedia(item: MediaEntry, type: String) {
        try {
            setPending(if (type == EXPLICIT) "TRASH_EXPLICIT" else "TRASH_NORMAL", media = item)
            launchSystemRequest(MediaStore.createTrashRequest(contentResolver, listOf(item.uri), true).intentSender)
        } catch (e: Exception) { toast("Android अनुमति अनुरोध शुरू नहीं हो सका: ${e.message ?: "अज्ञात त्रुटि"}") }
    }

    fun restoreMedia(record: TrashRecord) {
        try {
            setPending("RESTORE", record = record)
            launchSystemRequest(MediaStore.createTrashRequest(contentResolver, listOf(Uri.parse(record.uri)), false).intentSender)
        } catch (e: Exception) { toast("Restore अनुरोध शुरू नहीं हो सका। रिकॉर्ड सुरक्षित रखा गया है।") }
    }

    fun permanentlyDeleteRecord(record: TrashRecord) {
        try {
            setPending("PERMANENT_DELETE", record = record)
            launchSystemRequest(MediaStore.createDeleteRequest(contentResolver, listOf(Uri.parse(record.uri))).intentSender)
        } catch (e: Exception) { toast("Delete अनुरोध शुरू नहीं हो सका। रिकॉर्ड सुरक्षित रखा गया है।") }
    }

    fun permanentlyDeleteExpired(records: List<TrashRecord>) {
        val expired = records.filter { it.expiryAt <= System.currentTimeMillis() }
        if (expired.isEmpty()) return
        try {
            setPending("EXPIRED_DELETE")
            launchSystemRequest(MediaStore.createDeleteRequest(contentResolver, expired.map { Uri.parse(it.uri) }).intentSender)
        } catch (e: Exception) { toast("कुछ expired media हटाने के लिए ऐप खुला रखकर दोबारा प्रयास करें।") }
    }

    fun setRefreshCallback(callback: () -> Unit) { refreshAfterAction = callback }
    fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartGalleryScreen(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SmartGalleryScreen(activity: MainActivity) {
    val context = activity
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    val permissions = remember { arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO) }
    var hasPermission by remember { mutableStateOf(permissions.any { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }) }
    var media by remember { mutableStateOf(emptyList<MediaEntry>()) }
    var trash by remember { mutableStateOf(loadTrash(prefs)) }
    var page by remember { mutableStateOf("Photos") }
    var menu by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<MediaEntry?>(null) }
    var explicitSelected by remember { mutableStateOf<MediaEntry?>(null) }
    var aiResults by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var scanningUris by remember { mutableStateOf<Set<String>>(emptySet()) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasPermission = permissions.any { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
        if (hasPermission) media = queryMedia(context)
    }

    fun refresh() { media = queryMedia(context); trash = loadTrash(prefs) }
    LaunchedEffect(Unit) {
        activity.setRefreshCallback { refresh() }
        trash = loadTrash(prefs)
        if (hasPermission) { media = queryMedia(context); activity.permanentlyDeleteExpired(trash) }
    }

    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = { Text("SmartGallery") }, actions = {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Menu") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    listOf("Photos" to "Photos & Videos", "Delete Box" to "Delete Box (7 दिन)", "Explicit Box" to "Explicit Box (24 घंटे)", "Settings" to "Settings / जानकारी").forEach { (key, label) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { page = key; menu = false; refresh() })
                    }
                }
            })
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
                if (!hasPermission) {
                    Text("फोटो और वीडियो दिखाने के लिए Android की मीडिया अनुमति दें।")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { permissionLauncher.launch(permissions) }) { Text("अनुमति दें") }
                } else when (page) {
                    "Delete Box" -> TrashPage(trash.filter { it.type == NORMAL }, onRestore = activity::restoreMedia, onDelete = activity::permanentlyDeleteRecord)
                    "Explicit Box" -> TrashPage(trash.filter { it.type == EXPLICIT }, onRestore = activity::restoreMedia, onDelete = activity::permanentlyDeleteRecord)
                    "Settings" -> {
                        Text("SmartGallery सेटिंग्स", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        Text("• सामान्य Delete Box: 7 दिन की recovery अवधि।")
                        Text("• Explicit Box: यूज़र द्वारा स्वयं चुनी गई media के लिए 24 घंटे की अवधि।")
                        Text("• कोई PIN, पासवर्ड या biometric lock नहीं।")
                        Text("• AI पहचान: फोटो के लिए NSFW स्कोर उपलब्ध है; यह नग्न/यौन सामग्री का संकेत देता है, हर प्रकार की असुरक्षित सामग्री नहीं।")
                        Text("• AI परिणाम केवल समीक्षा का सुझाव है। कोई फोटो/वीडियो AI अनुमान से अपने-आप delete नहीं होगी।")
                        Text("• AI चलाने के लिए nsfw.tflite मॉडल को app/src/main/assets/ में रखना होगा। मॉडल न होने पर AI स्कैन काम नहीं करेगा।")
                        Text("• Android स्थायी deletion के लिए सिस्टम confirmation दिखाता है। समय पूरा होने पर ऐप खुलने पर confirmation माँगी जाती है; Android अनुमति के बिना चुपचाप स्थायी deletion नहीं की जाती।")
                        Text("• यह source project है; build और असली फोन पर परीक्षण अभी प्रमाणित नहीं है।")
                    }
                    else -> {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("फोटो और वीडियो", style = MaterialTheme.typography.titleMedium)
                            TextButton(onClick = { refresh() }) { Text("Refresh") }
                        }
                        if (media.isEmpty()) Text("कोई media नहीं मिली। अनुमति जाँचें या Refresh दबाएँ।")
                        LazyVerticalGrid(columns = GridCells.Adaptive(145.dp), contentPadding = PaddingValues(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(media, key = { it.uri.toString() }) { item ->
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(10.dp)) {
                                        Text(if (item.isVideo) "▶ VIDEO" else "▣ PHOTO", style = MaterialTheme.typography.labelLarge)
                                        Text(item.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        Spacer(Modifier.height(8.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            TextButton(onClick = { selected = item }) { Text("Delete") }
                                            TextButton(onClick = { explicitSelected = item }) { Text("Explicit") }
                                        }
                                        if (!item.isVideo) {
                                            TextButton(
                                                enabled = item.uri.toString() !in scanningUris,
                                                onClick = {
                                                    val key = item.uri.toString()
                                                    scanningUris = scanningUris + key
                                                    aiResults = aiResults + (key to "AI स्कैन चल रहा है…")
                                                    Thread {
                                                        try {
                                                            SmartGalleryAi.initialize(context)
                                                            val bitmap = context.contentResolver.openInputStream(item.uri)?.use { stream ->
                                                                BitmapFactory.decodeStream(stream)
                                                            } ?: throw IllegalStateException("फोटो पढ़ नहीं सकी")
                                                            NSFWHelper.getNSFWScore(bitmap) { score ->
                                                                val nsfw = score.nsfwScore
                                                                val message = when {
                                                                    nsfw >= 0.70f -> "AI संकेत: समीक्षा करें (${(nsfw * 100).toInt()}% स्कोर)। अपने-आप delete नहीं होगा।"
                                                                    nsfw >= 0.45f -> "AI परिणाम अनिश्चित (${(nsfw * 100).toInt()}% स्कोर)। मैन्युअल समीक्षा करें।"
                                                                    else -> "AI स्कोर कम (${(nsfw * 100).toInt()}%); यह 100% सुरक्षा की गारंटी नहीं है।"
                                                                }
                                                                aiResults = aiResults + (key to message)
                                                                scanningUris = scanningUris - key
                                                                bitmap.recycle()
                                                            }
                                                        } catch (e: Exception) {
                                                            aiResults = aiResults + (key to "AI उपलब्ध नहीं: ${e.message ?: "nsfw.tflite मॉडल assets में रखें"}")
                                                            scanningUris = scanningUris - key
                                                        }
                                                    }.start()
                                                }
                                            ) { Text(if (item.uri.toString() in scanningUris) "AI जाँच…" else "AI जाँच") }
                                            aiResults[item.uri.toString()]?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                                        } else {
                                            Text("वीडियो का AI स्कैन इस संस्करण में उपलब्ध नहीं है।", style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        selected?.let { item ->
            AlertDialog(onDismissRequest = { selected = null }, title = { Text("Delete Box में रखें?") }, text = { Text("${item.name}\nAndroid की अनुमति के बाद यह media सिस्टम trash में जाएगी और 7 दिन की recovery सूची में रहेगी।") }, confirmButton = {
                TextButton(onClick = { selected = null; activity.trashMedia(item, NORMAL) }) { Text("Confirm") }
            }, dismissButton = { TextButton(onClick = { selected = null }) { Text("Cancel") } })
        }
        explicitSelected?.let { item ->
            AlertDialog(onDismissRequest = { explicitSelected = null }, title = { Text("Explicit Box में रखें?") }, text = { Text("यह AI पहचान नहीं है। केवल अपनी पुष्टि के बाद चुनें। 24 घंटे बाद स्थायी deletion के लिए Android confirmation माँगी जाएगी।") }, confirmButton = {
                TextButton(onClick = { explicitSelected = null; activity.trashMedia(item, EXPLICIT) }) { Text("Confirm") }
            }, dismissButton = { TextButton(onClick = { explicitSelected = null }) { Text("Cancel") } })
        }
    }
}

@Composable
private fun TrashPage(records: List<TrashRecord>, onRestore: (TrashRecord) -> Unit, onDelete: (TrashRecord) -> Unit) {
    if (records.isEmpty()) { Text("यह बॉक्स खाली है।"); return }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(records, key = { it.key }) { record ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(record.name, style = MaterialTheme.typography.titleMedium)
                    Text(if (record.type == EXPLICIT) "24 घंटे की अवधि" else "7 दिन की अवधि")
                    Text("समाप्ति: ${DateFormat.getDateTimeInstance().format(Date(record.expiryAt))}")
                    Row {
                        TextButton(onClick = { onRestore(record) }) { Icon(Icons.Default.Restore, contentDescription = null); Text("Restore") }
                        TextButton(onClick = { onDelete(record) }) { Icon(Icons.Default.Delete, contentDescription = null); Text("Permanently delete") }
                    }
                }
            }
        }
    }
}

private fun queryMedia(context: Context): List<MediaEntry> {
    val result = mutableListOf<MediaEntry>()
    val resolver = context.contentResolver
    val collections = listOf(MediaStore.Images.Media.EXTERNAL_CONTENT_URI to false, MediaStore.Video.Media.EXTERNAL_CONTENT_URI to true)
    for ((collection, isVideo) in collections) {
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.DATE_ADDED)
        try {
            resolver.query(collection, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    result.add(MediaEntry(id, ContentUris.withAppendedId(collection, id), cursor.getString(nameCol) ?: "Media $id", isVideo, cursor.getLong(dateCol)))
                }
            }
        } catch (_: SecurityException) { }
    }
    return result.sortedByDescending { it.dateAdded }
}

private fun loadTrash(prefs: android.content.SharedPreferences): List<TrashRecord> {
    val result = mutableListOf<TrashRecord>()
    val arr = try { JSONArray(prefs.getString(KEY_TRASH, "[]")) } catch (_: Exception) { JSONArray() }
    for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        val type = o.optString("type", NORMAL).let { if (it == EXPLICIT) EXPLICIT else NORMAL }
        val uri = o.optString("uri")
        if (uri.isBlank()) continue
        result.add(TrashRecord(o.optString("key", UUID.randomUUID().toString()), uri, o.optString("name", "Media"), o.optBoolean("isVideo"), o.optLong("deletedAt"), type))
    }
    return result
}

private fun saveTrash(prefs: android.content.SharedPreferences, records: List<TrashRecord>) {
    val arr = JSONArray()
    records.forEach { r -> arr.put(JSONObject().apply {
        put("key", r.key); put("uri", r.uri); put("name", r.name); put("isVideo", r.isVideo); put("deletedAt", r.deletedAt); put("type", r.type)
    }) }
    prefs.edit().putString(KEY_TRASH, arr.toString()).apply()
}
